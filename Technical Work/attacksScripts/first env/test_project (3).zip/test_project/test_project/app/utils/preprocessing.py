def preprocess_input(df, label_encoders, scaler):
    for col in label_encoders:
        df[col] = label_encoders[col].transform(df[col])
    
    df_scaled = scaler.transform(df.values)
    return df_scaled
