from flask import Flask, render_template
import tensorflow as tf
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import confusion_matrix, accuracy_score, recall_score, precision_score, f1_score
import os


template_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../templates'))
app = Flask(__name__, template_folder=template_dir)


model = tf.keras.models.load_model('app/model/model.h5')


DEFAULT_CSV_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../client1/network_traffic.csv'))

def process_file(file_path):
    try:
        data = pd.read_csv(file_path)
        data.columns = data.columns.str.strip()

        df_cleaned = data.drop(['No.', 'Time', 'Type of attack'], axis=1)

        categorical_columns = df_cleaned.select_dtypes(include=['object']).columns
        for col in categorical_columns:
            le = LabelEncoder()
            df_cleaned[col] = le.fit_transform(df_cleaned[col])

        X_new = df_cleaned.drop(['Type'], axis=1)
        y_new = df_cleaned['Type']

        scaler = StandardScaler()
        X_new_scaled = scaler.fit_transform(X_new)

        predictions = model.predict(X_new_scaled)
        predictions_class = (predictions > 0.5).astype(int).flatten()

        cm = confusion_matrix(y_new, predictions_class)
        tn, fp, fn, tp = cm.ravel()

        accuracy = accuracy_score(y_new, predictions_class)
        precision = precision_score(y_new, predictions_class)
        recall = recall_score(y_new, predictions_class)
        f1 = f1_score(y_new, predictions_class)

        return {
            "status": "success",
            "total_predictions": len(predictions_class),
            "predicted_attacks": (predictions_class == 1).sum(),
            "predicted_normal": (predictions_class == 0).sum(),
            "accuracy": round(accuracy, 4),
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1_score": round(f1, 4),
            "tn": tn,
            "fp": fp,
            "fn": fn,
            "tp": tp
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e)
        }

@app.route('/')
def show_results():

    result = process_file(DEFAULT_CSV_PATH)
    
    if result['status'] == 'error':
        return render_template('error.html', error=result['message'])
    
    return render_template('result.html', result=result)

if __name__ == '__main__':

    print(f"Current directory: {os.getcwd()}")
    print(f"Template directory: {app.template_folder}")
    print(f"Default CSV path: {DEFAULT_CSV_PATH}")
    app.run(debug=True)